"use client";

import { useEffect, useState } from "react";

export function OnlineCounter() {
  const [count, setCount] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function fetchCount() {
      try {
        const res = await fetch("/api/online");
        if (res.ok) {
          const data = await res.json();
          if (mounted) {
            setCount(data.count ?? 0);
          }
        } else {
          if (mounted) setCount(0);
        }
      } catch {
        if (mounted) setCount(0);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    fetchCount();
    const interval = setInterval(fetchCount, 15000); // refresh every 15s

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border text-sm">
      <span className="w-2 h-2 rounded-full bg-online pulse-online" />
      {loading ? (
        <span className="text-muted">Checking online users...</span>
      ) : (
        <span>
          <span className="font-semibold text-foreground">
            {count?.toLocaleString() ?? 0}
          </span>{" "}
          <span className="text-muted">Strangers Online Now</span>
        </span>
      )}
    </div>
  );
}
