import Link from "next/link";
import Image from "next/image";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Image
                src="/logo.png"
                alt="MixTalk"
                width={36}
                height={36}
                className="rounded-lg"
              />
              <span className="text-lg font-bold">
                <span className="text-foreground">Mix</span>
                <span className="gradient-text">Talk</span>
              </span>
            </Link>
            <p className="text-sm text-muted leading-relaxed">
              Meet. Talk. Connect.
              <br />
              Adults-only random conversations worldwide.
            </p>
            <p className="mt-3 text-xs font-semibold text-neon-pink">
              18+ Adults Only
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">
              Platform
            </h3>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <Link href="/about" className="hover:text-foreground transition-colors">
                  About MixTalk
                </Link>
              </li>
              <li>
                <Link href="/safety" className="hover:text-foreground transition-colors">
                  Safety
                </Link>
              </li>
              <li>
                <Link href="/community-guidelines" className="hover:text-foreground transition-colors">
                  Community Guidelines
                </Link>
              </li>
              <li>
                <Link href="/chat" className="hover:text-foreground transition-colors">
                  Start Chatting
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <Link href="/privacy" className="hover:text-foreground transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-foreground transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">
              Support
            </h3>
            <ul className="space-y-2 text-sm text-muted">
              <li>
                <Link href="/feedback" className="hover:text-foreground transition-colors">
                  Feedback
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-foreground transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted">
            © {year} MixTalk. All rights reserved.
          </p>
          <p className="text-xs text-muted text-center sm:text-right max-w-md">
            MixTalk is designed for eligible adults aged 18+. Self-declaration is a UI gate only and is not claimed as legally sufficient age verification.
          </p>
        </div>
      </div>
    </footer>
  );
}
