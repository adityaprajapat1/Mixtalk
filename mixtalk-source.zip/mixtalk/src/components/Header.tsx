"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, Globe, Moon, Sun } from "@/components/Icons";

const navItems = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About MixTalk" },
  { href: "/safety", label: "Safety" },
  { href: "/community-guidelines", label: "Community Guidelines" },
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms of Service" },
  { href: "/feedback", label: "Feedback" },
  { href: "/contact", label: "Contact Us" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const theme = "dark";
  const setTheme = (_: string) => {};

  return (
    <header className="sticky top-0 z-50 glass border-b border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <Image
              src="/logo.png"
              alt="MixTalk"
              width={40}
              height={40}
              className="rounded-lg"
              priority
            />
            <span className="text-xl font-bold tracking-tight">
              <span className="text-foreground">Mix</span>
              <span className="gradient-text">Talk</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.slice(0, 5).map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm text-muted hover:text-foreground transition-colors rounded-lg hover:bg-white/5"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="p-2 rounded-lg text-muted hover:text-foreground hover:bg-white/5 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            <button
              className="p-2 rounded-lg text-muted hover:text-foreground hover:bg-white/5 transition-colors hidden sm:flex"
              aria-label="Language"
            >
              <Globe size={20} />
            </button>

            <Link
              href="/chat"
              className="hidden sm:inline-flex btn-primary text-sm py-2 px-4"
            >
              Start Chatting
            </Link>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 rounded-lg text-muted hover:text-foreground hover:bg-white/5"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-border glass">
          <nav className="px-4 py-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="block px-4 py-3 text-base text-foreground hover:bg-white/5 rounded-xl transition-colors"
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-3 border-t border-border">
              <Link
                href="/chat"
                onClick={() => setMobileOpen(false)}
                className="block w-full text-center btn-primary"
              >
                Start Chatting
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
