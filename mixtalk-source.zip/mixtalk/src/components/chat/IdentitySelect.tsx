"use client";

interface Props {
  onSelect: (gender: "boy" | "girl") => void;
}

export function IdentitySelect({ onSelect }: Props) {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <h1 className="text-2xl sm:text-3xl font-bold mb-3">
          How do you identify?
        </h1>
        <p className="text-muted text-sm mb-8">
          Selection is voluntary. This helps with conversation variety and is
          not used for automatic moderation decisions.
        </p>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => onSelect("boy")}
            className="glass rounded-2xl p-8 hover:bg-card-hover transition-all hover:scale-[1.02] border border-border hover:border-neon-blue/50"
          >
            <div className="text-4xl mb-3">👨</div>
            <span className="font-semibold text-lg">Boy</span>
          </button>
          <button
            onClick={() => onSelect("girl")}
            className="glass rounded-2xl p-8 hover:bg-card-hover transition-all hover:scale-[1.02] border border-border hover:border-neon-pink/50"
          >
            <div className="text-4xl mb-3">👩</div>
            <span className="font-semibold text-lg">Girl</span>
          </button>
        </div>
      </div>
    </div>
  );
}
