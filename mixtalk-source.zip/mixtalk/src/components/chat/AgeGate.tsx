"use client";

import Image from "next/image";
import { Shield } from "@/components/Icons";

interface Props {
  onYes: () => void;
  onNo: () => void;
}

export function AgeGate({ onYes, onNo }: Props) {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <Image
          src="/logo.png"
          alt="MixTalk"
          width={80}
          height={80}
          className="mx-auto mb-6 rounded-xl"
        />
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-xs font-semibold mb-6">
          <Shield className="w-3.5 h-3.5" />
          18+ Adults Only
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-3">
          Are you 18 years old or older?
        </h1>
        <p className="text-muted text-sm mb-8 leading-relaxed">
          MixTalk is strictly for eligible adults. This self-declaration is a
          UI gate only and is not claimed as legally sufficient age verification.
          Stronger age-assurance may be required in some jurisdictions.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button onClick={onYes} className="btn-primary w-full sm:w-auto">
            Yes, I&apos;m 18+
          </button>
          <button onClick={onNo} className="btn-secondary w-full sm:w-auto">
            No, I&apos;m under 18
          </button>
        </div>
      </div>
    </div>
  );
}
