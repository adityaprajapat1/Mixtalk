"use client";

import Image from "next/image";
import Link from "next/link";

export function Under18() {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <Image
          src="/logo.png"
          alt="MixTalk"
          width={80}
          height={80}
          className="mx-auto mb-6 rounded-xl opacity-60"
        />
        <h1 className="text-2xl font-bold mb-3">MixTalk is an adults-only platform.</h1>
        <p className="text-muted mb-8">
          You must be 18 years of age or older to use MixTalk. Thank you for
          being honest.
        </p>
        <Link href="/" className="btn-secondary">
          Leave
        </Link>
      </div>
    </div>
  );
}
