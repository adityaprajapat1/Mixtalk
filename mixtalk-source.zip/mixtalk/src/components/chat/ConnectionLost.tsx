"use client";

interface Props {
  onReconnect: () => void;
  onFindOther: () => void;
  onEnd: () => void;
}

export function ConnectionLost({ onReconnect, onFindOther, onEnd }: Props) {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <div className="text-5xl mb-6">📡</div>
        <h1 className="text-2xl font-bold mb-3">Connection lost.</h1>
        <p className="text-muted mb-8">
          We lost connection to the matching service. You can try reconnecting
          or find someone else.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button onClick={onReconnect} className="btn-primary">
            Reconnect
          </button>
          <button onClick={onFindOther} className="btn-secondary">
            Find Someone Else
          </button>
          <button onClick={onEnd} className="btn-secondary">
            End Chat
          </button>
        </div>
      </div>
    </div>
  );
}
