"use client";

interface Props {
  onTryAgain: () => void;
  onHome: () => void;
}

export function NoUsers({ onTryAgain, onHome }: Props) {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <div className="text-5xl mb-6">🌍</div>
        <h1 className="text-2xl font-bold mb-3">No users available right now.</h1>
        <p className="text-muted mb-8">
          There are no suitable matches at the moment. Please try again in a
          little while.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button onClick={onTryAgain} className="btn-primary">
            Try Again
          </button>
          <button onClick={onHome} className="btn-secondary">
            Return Home
          </button>
        </div>
      </div>
    </div>
  );
}
