"use client";

import { MessageSquare, Mic, Video } from "@/components/Icons";

interface Props {
  nickname: string;
  onSelect: (mode: "text" | "voice" | "video") => void;
}

export function ModeSelect({ nickname, onSelect }: Props) {
  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-lg text-center">
        <p className="text-sm text-muted mb-2">Your temporary nickname</p>
        <h2 className="text-2xl font-bold gradient-text mb-8">{nickname}</h2>
        <h1 className="text-2xl sm:text-3xl font-bold mb-3">
          Choose how to connect
        </h1>
        <p className="text-muted text-sm mb-8">
          You can switch modes later. Your nickname stays the same for this session.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            onClick={() => onSelect("text")}
            className="glass rounded-2xl p-6 hover:bg-card-hover transition-all hover:scale-[1.02] border border-border hover:border-neon-blue/50 group"
          >
            <MessageSquare className="w-10 h-10 mx-auto mb-3 text-neon-blue group-hover:scale-110 transition-transform" />
            <span className="font-semibold">Text Chat</span>
          </button>
          <button
            onClick={() => onSelect("voice")}
            className="glass rounded-2xl p-6 hover:bg-card-hover transition-all hover:scale-[1.02] border border-border hover:border-neon-purple/50 group"
          >
            <Mic className="w-10 h-10 mx-auto mb-3 text-neon-purple group-hover:scale-110 transition-transform" />
            <span className="font-semibold">Voice Call</span>
          </button>
          <button
            onClick={() => onSelect("video")}
            className="glass rounded-2xl p-6 hover:bg-card-hover transition-all hover:scale-[1.02] border border-border hover:border-neon-pink/50 group"
          >
            <Video className="w-10 h-10 mx-auto mb-3 text-neon-pink group-hover:scale-110 transition-transform" />
            <span className="font-semibold">Video Call</span>
          </button>
        </div>
      </div>
    </div>
  );
}
