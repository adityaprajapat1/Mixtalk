"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import Image from "next/image";
import {
  MessageSquare, Mic, Video, MicOff, VideoOff, SkipForward,
  Flag, Ban, PhoneOff, Send,
} from "@/components/Icons";
import { SessionState } from "@/app/chat/page";
import { ReportModal } from "./ReportModal";
import { io, Socket } from "socket.io-client";
import { createPeerConnection } from "@/lib/webrtc";

interface Message {
  id: string;
  text: string;
  fromMe: boolean;
  timestamp: Date;
}

interface Props {
  session: SessionState;
  onSkip: () => void;
  onEnd: () => void;
  onConnectionLost: () => void;
}

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || "";

export function ChatRoom({ session, onSkip, onEnd, onConnectionLost }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [showReport, setShowReport] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  const [connStatus, setConnStatus] = useState("Connecting...");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  const shortSession = session.sessionId.replace(/-/g, "").slice(0, 8).toUpperCase();
  const isMedia = session.mode === "voice" || session.mode === "video";

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // WebSocket connection
  useEffect(() => {
    if (!session.sessionId || !session.matchId) return;

    const url = WS_URL || window.location.origin.replace(/:\d+$/, ":3001");
    let socket: Socket;
    try {
      socket = io(url, {
        path: "/ws",
        transports: ["websocket", "polling"],
        autoConnect: true,
      });
    } catch {
      setConnStatus("WebSocket unavailable");
      return;
    }

    socketRef.current = socket;

    socket.on("connect", () => {
      setWsConnected(true);
      setConnStatus("Connected");
      socket.emit("auth", { sessionId: session.sessionId }, (res: any) => {
        if (res?.ok) {
          socket.emit("join_match", { matchId: session.matchId });
        } else {
          setConnStatus("Auth failed");
        }
      });
    });

    socket.on("disconnect", () => {
      setWsConnected(false);
      setConnStatus("Disconnected");
    });

    socket.on("message", (msg: { id: string; from: string; text: string; ts: number }) => {
      setMessages((prev) => {
        if (prev.some((m) => m.id === msg.id)) return prev;
        return [
          ...prev,
          {
            id: msg.id,
            text: msg.text,
            fromMe: msg.from === session.sessionId,
            timestamp: new Date(msg.ts),
          },
        ];
      });
    });

    socket.on("typing", (p: { from: string; typing: boolean }) => {
      if (p.from !== session.sessionId) setIsTyping(p.typing);
    });

    socket.on("match:ended", () => {
      setConnStatus("Partner left");
    });

    socket.on("partner:disconnected", () => {
      setConnStatus("Partner disconnected");
    });

    // WebRTC signaling
    socket.on("webrtc:offer", async (p: { from: string; sdp: RTCSessionDescriptionInit }) => {
      if (p.from === session.sessionId || !pcRef.current) return;
      await pcRef.current.setRemoteDescription(p.sdp);
      const answer = await pcRef.current.createAnswer();
      await pcRef.current.setLocalDescription(answer);
      socket.emit("webrtc:answer", { matchId: session.matchId, sdp: answer });
    });

    socket.on("webrtc:answer", async (p: { from: string; sdp: RTCSessionDescriptionInit }) => {
      if (p.from === session.sessionId || !pcRef.current) return;
      await pcRef.current.setRemoteDescription(p.sdp);
    });

    socket.on("webrtc:ice", async (p: { from: string; candidate: RTCIceCandidateInit }) => {
      if (p.from === session.sessionId || !pcRef.current) return;
      try {
        await pcRef.current.addIceCandidate(p.candidate);
      } catch {
        // ignore late candidates
      }
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [session.sessionId, session.matchId]);

  // Media setup for voice/video
  useEffect(() => {
    if (!isMedia || !session.matchId) return;
    let cancelled = false;

    async function setupMedia() {
      try {
        const constraints: MediaStreamConstraints = {
          audio: true,
          video: session.mode === "video",
        };
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        const pc = await createPeerConnection(
          (candidate) => {
            socketRef.current?.emit("webrtc:ice", {
              matchId: session.matchId,
              candidate,
            });
          },
          (ev) => {
            if (remoteVideoRef.current && ev.streams[0]) {
              remoteVideoRef.current.srcObject = ev.streams[0];
            }
          }
        );
        pcRef.current = pc;
        stream.getTracks().forEach((t) => pc.addTrack(t, stream));

        // Initiator: create offer (lexicographically smaller session id)
        if (session.sessionId < (session.partnerNickname || "")) {
          // Use session id comparison with a stable rule: lower UUID offers
        }
        // Both sides can offer; the one that connects first wins via glare handling simplified:
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socketRef.current?.emit("webrtc:offer", {
          matchId: session.matchId,
          sdp: offer,
        });
      } catch (err) {
        console.warn("[media]", err);
        setConnStatus("Media permission denied or unavailable");
      }
    }

    setupMedia();
    return () => {
      cancelled = true;
      localStreamRef.current?.getTracks().forEach((t) => t.stop());
      pcRef.current?.close();
      pcRef.current = null;
    };
  }, [isMedia, session.matchId, session.mode, session.sessionId, session.partnerNickname]);

  const sendMessage = useCallback(() => {
    if (!input.trim() || !session.matchId) return;
    const text = input.trim();
    setInput("");

    if (socketRef.current?.connected) {
      socketRef.current.emit(
        "message",
        { matchId: session.matchId, text },
        (res: { ok: boolean; id?: string }) => {
          if (res?.ok && res.id) {
            setMessages((prev) => [
              ...prev,
              { id: res.id!, text, fromMe: true, timestamp: new Date() },
            ]);
          }
        }
      );
    } else {
      // Optimistic local only when WS down — do not fake partner delivery
      setMessages((prev) => [
        ...prev,
        {
          id: "local-" + Date.now(),
          text,
          fromMe: true,
          timestamp: new Date(),
        },
      ]);
    }
  }, [input, session.matchId]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleTyping = (val: string) => {
    setInput(val);
    socketRef.current?.emit("typing", {
      matchId: session.matchId,
      typing: val.length > 0,
    });
  };

  const handleSkip = async () => {
    socketRef.current?.emit("match:end", { matchId: session.matchId, reason: "skip" });
    await fetch("/api/match", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: session.sessionId, skip: true }),
    });
    onSkip();
  };

  const handleEnd = async () => {
    socketRef.current?.emit("match:end", { matchId: session.matchId, reason: "end" });
    await fetch("/api/match", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: session.sessionId, skip: false }),
    });
    onEnd();
  };

  const handleBlock = async () => {
    try {
      await fetch("/api/block", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: session.sessionId,
          matchId: session.matchId,
        }),
      });
    } catch {
      // still end
    }
    setShowBlockConfirm(false);
    onSkip();
  };

  const toggleMic = () => {
    const next = !micOn;
    setMicOn(next);
    localStreamRef.current?.getAudioTracks().forEach((t) => {
      t.enabled = next;
    });
  };

  const toggleCam = () => {
    const next = !camOn;
    setCamOn(next);
    localStreamRef.current?.getVideoTracks().forEach((t) => {
      t.enabled = next;
    });
  };

  return (
    <div className="flex flex-col h-screen max-h-screen relative">
      <div className="session-watermark">
        MixTalk • Session ID: {shortSession}
      </div>

      <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card/80 backdrop-blur shrink-0">
        <div className="flex items-center gap-3">
          <Image src="/logo.png" alt="MixTalk" width={32} height={32} className="rounded-lg" />
          <div>
            <p className="font-semibold text-sm">{session.partnerNickname || "Partner"}</p>
            <p className={`text-xs flex items-center gap-1 ${wsConnected ? "text-online" : "text-muted"}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${wsConnected ? "bg-online" : "bg-muted"}`} />
              {connStatus}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setShowReport(true)} className="p-2 rounded-lg text-muted hover:text-warning hover:bg-white/5" aria-label="Report" title="Report">
            <Flag size={20} />
          </button>
          <button onClick={() => setShowBlockConfirm(true)} className="p-2 rounded-lg text-muted hover:text-danger hover:bg-white/5" aria-label="Block" title="Block">
            <Ban size={20} />
          </button>
          <button onClick={handleSkip} className="p-2 rounded-lg text-muted hover:text-foreground hover:bg-white/5" aria-label="Skip" title="Skip">
            <SkipForward size={20} />
          </button>
          <button onClick={handleEnd} className="p-2 rounded-lg text-danger hover:bg-danger/10" aria-label="End chat" title="End">
            <PhoneOff size={20} />
          </button>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {isMedia && (
          <div className="relative bg-black/40 md:w-1/2 lg:w-3/5 flex items-center justify-center min-h-[200px] md:min-h-0">
            {session.mode === "video" ? (
              <>
                <video ref={remoteVideoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
                <video ref={localVideoRef} autoPlay playsInline muted className="absolute bottom-4 right-4 w-28 h-40 object-cover rounded-xl border border-border bg-black" />
              </>
            ) : (
              <div className="text-center text-muted">
                <Mic className="w-16 h-16 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Voice call</p>
                <p className="text-xs mt-1 opacity-60">{connStatus}</p>
                <audio ref={remoteVideoRef as any} autoPlay />
              </div>
            )}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-3 z-10">
              <button onClick={toggleMic} className={`p-3 rounded-full ${micOn ? "bg-card" : "bg-danger"} border border-border`} aria-label={micOn ? "Mute" : "Unmute"}>
                {micOn ? <Mic size={20} /> : <MicOff size={20} />}
              </button>
              {session.mode === "video" && (
                <button onClick={toggleCam} className={`p-3 rounded-full ${camOn ? "bg-card" : "bg-danger"} border border-border`} aria-label={camOn ? "Camera off" : "Camera on"}>
                  {camOn ? <Video size={20} /> : <VideoOff size={20} />}
                </button>
              )}
            </div>
          </div>
        )}

        <div className={`flex flex-col flex-1 ${isMedia ? "md:w-1/2 lg:w-2/5 border-l border-border" : ""}`}>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="text-center text-muted text-sm py-12">
                <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p>Say hello to {session.partnerNickname}!</p>
                {!wsConnected && (
                  <p className="text-xs mt-2 opacity-60">
                    Real-time messaging requires the WebSocket server (port 3001).
                  </p>
                )}
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.fromMe ? "justify-end" : "justify-start"} animate-slide-in`}>
                <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm ${
                  m.fromMe
                    ? "bg-gradient-to-r from-neon-blue/80 to-neon-purple/80 text-white rounded-br-md"
                    : "bg-card border border-border rounded-bl-md"
                }`}>
                  <p className="break-words">{m.text}</p>
                  <p className={`text-[10px] mt-1 ${m.fromMe ? "text-white/60" : "text-muted"}`}>
                    {m.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            ))}
            {isTyping && <div className="text-xs text-muted px-2">Partner is typing...</div>}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-3 border-t border-border bg-card/50 shrink-0">
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => handleTyping(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                className="flex-1 bg-background border border-border rounded-full px-4 py-2.5 text-sm focus:outline-none focus:border-neon-purple transition-colors"
                maxLength={1000}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim()}
                className="p-2.5 rounded-full bg-gradient-to-r from-neon-blue to-neon-purple text-white disabled:opacity-40 disabled:cursor-not-allowed"
                aria-label="Send"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {showReport && (
        <ReportModal
          sessionId={session.sessionId}
          matchId={session.matchId}
          onClose={() => setShowReport(false)}
        />
      )}

      {showBlockConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4">
          <div className="glass rounded-2xl p-6 max-w-sm w-full">
            <h3 className="text-lg font-semibold mb-2">Block this user?</h3>
            <p className="text-sm text-muted mb-6">
              You will end the current chat and will not be matched with this person again.
            </p>
            <div className="flex gap-3">
              <button onClick={handleBlock} className="btn-primary flex-1" style={{ background: "var(--danger)" }}>
                Block
              </button>
              <button onClick={() => setShowBlockConfirm(false)} className="btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
