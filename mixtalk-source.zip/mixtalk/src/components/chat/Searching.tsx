"use client";

import { useEffect, useState, useRef } from "react";
import { SessionState } from "@/app/chat/page";
import { Loader2 } from "@/components/Icons";

interface Props {
  session: SessionState;
  onMatched: (partnerNick: string, matchId: string, sessionId: string) => void;
  onNoUsers: () => void;
  onConnectionLost: () => void;
}

export function Searching({ session, onMatched, onNoUsers, onConnectionLost }: Props) {
  const [status, setStatus] = useState("Looking for someone...");
  const attempts = useRef(0);
  const cancelled = useRef(false);

  useEffect(() => {
    cancelled.current = false;
    attempts.current = 0;

    async function attempt() {
      if (cancelled.current) return;
      attempts.current += 1;

      try {
        setStatus(
          attempts.current === 1
            ? "Connecting to matching service..."
            : "Still searching for an eligible partner..."
        );

        const res = await fetch("/api/match", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sessionId: session.sessionId,
            nickname: session.nickname,
            gender: session.gender,
            mode: session.mode,
          }),
        });

        if (cancelled.current) return;

        if (res.status === 204) {
          onNoUsers();
          return;
        }

        if (res.status === 202) {
          // Searching — poll again after short delay
          const data = await res.json();
          if (data.sessionId && data.sessionId !== session.sessionId) {
            // server assigned new session id
          }
          if (attempts.current >= 12) {
            // ~30s of searching
            onNoUsers();
            return;
          }
          setTimeout(attempt, 2500);
          return;
        }

        if (!res.ok) {
          onConnectionLost();
          return;
        }

        const data = await res.json();
        if (data.status === "matched" && data.partnerNickname && data.matchId) {
          onMatched(data.partnerNickname, data.matchId, data.sessionId || session.sessionId);
        } else if (data.status === "searching") {
          if (attempts.current >= 12) {
            onNoUsers();
            return;
          }
          setTimeout(attempt, 2500);
        } else {
          onNoUsers();
        }
      } catch {
        if (!cancelled.current) onConnectionLost();
      }
    }

    const t = setTimeout(attempt, 600);
    return () => {
      cancelled.current = true;
      clearTimeout(t);
    };
  }, [session, onMatched, onNoUsers, onConnectionLost]);

  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md text-center">
        <div className="relative w-24 h-24 mx-auto mb-8">
          <div className="absolute inset-0 rounded-full border-2 border-neon-purple/30 animate-ping" />
          <div className="absolute inset-2 rounded-full border-2 border-neon-blue/40 animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="w-10 h-10 text-neon-purple animate-spin" />
          </div>
        </div>
        <h1 className="text-xl font-semibold mb-2">{status}</h1>
        <p className="text-muted text-sm">
          You are <span className="text-foreground font-medium">{session.nickname}</span>
        </p>
        <p className="text-muted text-xs mt-4">
          Mode:{" "}
          {session.mode === "text"
            ? "Text Chat"
            : session.mode === "voice"
            ? "Voice Call"
            : "Video Call"}
        </p>
      </div>
    </div>
  );
}
