"use client";

import { useState } from "react";
import { X } from "@/components/Icons";

const REASONS = [
  "Harassment",
  "Abusive behavior",
  "Threatening behavior",
  "Spam",
  "Scam/fraud",
  "Inappropriate behavior",
  "Impersonation",
  "Other",
];

interface Props {
  sessionId: string;
  matchId: string | null;
  onClose: () => void;
}

export function ReportModal({ sessionId, matchId, onClose }: Props) {
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!reason) return;
    setLoading(true);
    try {
      await fetch("/api/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          matchId,
          reason,
          description: description.trim() || undefined,
        }),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true); // still show thank you
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4">
        <div className="glass rounded-2xl p-6 max-w-sm w-full text-center">
          <div className="text-4xl mb-4">✓</div>
          <h3 className="text-lg font-semibold mb-2">Thank you</h3>
          <p className="text-sm text-muted mb-6">
            Your report has been submitted for review.
          </p>
          <button onClick={onClose} className="btn-primary w-full">
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4">
      <div className="glass rounded-2xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Report User</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/10">
            <X size={20} />
          </button>
        </div>
        <p className="text-sm text-muted mb-4">
          Select a reason. Reports are reviewed by moderators.
        </p>
        <div className="space-y-2 mb-4">
          {REASONS.map((r) => (
            <label
              key={r}
              className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                reason === r
                  ? "border-neon-purple bg-neon-purple/10"
                  : "border-border hover:bg-white/5"
              }`}
            >
              <input
                type="radio"
                name="reason"
                value={r}
                checked={reason === r}
                onChange={() => setReason(r)}
                className="accent-purple-500"
              />
              <span className="text-sm">{r}</span>
            </label>
          ))}
        </div>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Optional description..."
          rows={3}
          maxLength={500}
          className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm mb-4 focus:outline-none focus:border-neon-purple resize-none"
        />
        <div className="flex gap-3">
          <button
            onClick={handleSubmit}
            disabled={!reason || loading}
            className="btn-primary flex-1 disabled:opacity-40"
          >
            {loading ? "Submitting..." : "Submit Report"}
          </button>
          <button onClick={onClose} className="btn-secondary">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
