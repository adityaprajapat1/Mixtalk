"use client";

import { ReactNode } from "react";

export function Providers({ children }: { children: ReactNode }) {
  // Dark-first by default. Theme toggle can be added later with next-themes.
  return <>{children}</>;
}
