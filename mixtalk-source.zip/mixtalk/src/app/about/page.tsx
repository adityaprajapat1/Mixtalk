import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MessageSquare, SkipForward, Shield, Globe2 } from "@/components/Icons";

export const metadata = { title: "About MixTalk" };

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-3xl sm:text-4xl font-bold mb-6">About MixTalk</h1>
          <p className="text-lg text-muted leading-relaxed mb-8">
            MixTalk is a platform for eligible adults to meet and talk with new
            people from different countries and cultures through random text,
            voice and video conversations.
          </p>
          <div className="space-y-6">
            <div className="glass rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-3">
                <Globe2 className="w-6 h-6 text-neon-blue" />
                <h2 className="text-xl font-semibold">Global Communication</h2>
              </div>
              <p className="text-muted text-sm leading-relaxed">
                Connect with people across the world. Every match is random and
                brings the chance to discover new perspectives and cultures.
              </p>
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-3">
                <MessageSquare className="w-6 h-6 text-neon-blue" />
                <h2 className="text-xl font-semibold">Text, Voice & Video</h2>
              </div>
              <p className="text-muted text-sm leading-relaxed">
                Choose the way you prefer to communicate. Start with text, or
                jump into voice or video calls powered by secure real-time
                technology.
              </p>
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-3">
                <SkipForward className="w-6 h-6 text-neon-purple" />
                <h2 className="text-xl font-semibold">Skip / Next</h2>
              </div>
              <p className="text-muted text-sm leading-relaxed">
                Not connecting with someone? Use Skip to end the conversation
                and instantly look for a new eligible person. Your temporary
                nickname stays the same throughout the session.
              </p>
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-6 h-6 text-neon-pink" />
                <h2 className="text-xl font-semibold">Safety Tools</h2>
              </div>
              <p className="text-muted text-sm leading-relaxed">
                Report and Block are always available. Moderators review
                reports. Repeated or serious violations can lead to warnings,
                temporary suspension or permanent removal.
              </p>
            </div>
          </div>
          <p className="mt-10 text-sm text-muted">
            MixTalk is strictly for adults aged 18 and older.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}
