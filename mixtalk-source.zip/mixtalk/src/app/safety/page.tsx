import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Shield, AlertTriangle, Ban, Flag, Lock } from "@/components/Icons";

export const metadata = { title: "Safety at MixTalk" };

export default function SafetyPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-3xl sm:text-4xl font-bold mb-6">Safety at MixTalk</h1>
          
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-sm font-semibold mb-8">
            <Shield className="w-4 h-4" />
            18+ Adults Only
          </div>

          <div className="space-y-6 text-muted leading-relaxed">
            <p>
              MixTalk is designed for respectful conversations between eligible
              adults. We take safety seriously, but no platform can guarantee
              that every interaction is safe. Always use your own judgment.
            </p>

            <div className="glass rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-warning" />
                Core Rules
              </h2>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Be respectful.</li>
                <li>Harassment is not allowed.</li>
                <li>Threats are not allowed.</li>
                <li>Spam and scams are not allowed.</li>
                <li>Do not share sensitive personal information.</li>
              </ul>
            </div>

            <div className="glass rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <Ban className="w-5 h-5 text-danger" />
                Block
              </h2>
              <p className="text-sm">
                Use Block when you do not want further contact with someone.
                Blocked users will not be matched with you again.
              </p>
            </div>

            <div className="glass rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <Flag className="w-5 h-5 text-warning" />
                Report
              </h2>
              <p className="text-sm">
                Use Report when someone violates the rules. Reports are reviewed
                by moderators. Violations may result in warnings, suspension or
                permanent bans.
              </p>
            </div>

            <div className="glass rounded-2xl p-6 space-y-4">
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <Lock className="w-5 h-5 text-neon-blue" />
                Privacy Tips
              </h2>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Never share your real name, phone number, address or financial details.</li>
                <li>Be cautious of anyone asking for money or personal documents.</li>
                <li>You can end a conversation at any time with Skip or End.</li>
              </ul>
            </div>

            <p className="text-sm pt-4">
              MixTalk cannot guarantee that every interaction is safe. Stay
              alert, trust your instincts, and use the safety tools provided.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
