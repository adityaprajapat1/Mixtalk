"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import {
  Users, MessageSquare, Mic, Video, Flag, AlertTriangle,
  Ban, Activity, Settings, LogOut, Shield
} from "@/components/Icons";

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/admin/stats");
        if (res.status === 401 || res.status === 403) {
          setAuthError(true);
          return;
        }
        if (res.ok) {
          setStats(await res.json());
        }
      } catch {
        setAuthError(true);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (authError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted mb-6">You are not authorized to view this page.</p>
          <button onClick={() => router.push("/admin/login")} className="btn-primary">
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  const cards = [
    { label: "Active Users", value: stats?.activeUsers ?? "—", icon: Users, color: "text-neon-blue" },
    { label: "Text Chats", value: stats?.textChats ?? "—", icon: MessageSquare, color: "text-neon-blue" },
    { label: "Voice Calls", value: stats?.voiceCalls ?? "—", icon: Mic, color: "text-neon-purple" },
    { label: "Video Calls", value: stats?.videoCalls ?? "—", icon: Video, color: "text-neon-pink" },
    { label: "Pending Reports", value: stats?.pendingReports ?? "—", icon: Flag, color: "text-warning" },
    { label: "Warnings", value: stats?.warnings ?? "—", icon: AlertTriangle, color: "text-warning" },
    { label: "Suspensions", value: stats?.suspensions ?? "—", icon: Shield, color: "text-danger" },
    { label: "Permanent Bans", value: stats?.bans ?? "—", icon: Ban, color: "text-danger" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Image src="/logo.png" alt="MixTalk" width={32} height={32} className="rounded-lg" />
          <span className="font-bold">Admin Dashboard</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 rounded-lg text-muted hover:text-foreground hover:bg-white/5" title="Settings">
            <Settings size={20} />
          </button>
          <button
            onClick={() => router.push("/admin/login")}
            className="p-2 rounded-lg text-muted hover:text-danger hover:bg-white/5"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Overview</h1>

        {loading ? (
          <p className="text-muted">Loading real-time data...</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {cards.map((c) => (
              <div key={c.label} className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <c.icon className={`w-5 h-5 ${c.color}`} />
                  <Activity className="w-4 h-4 text-muted opacity-40" />
                </div>
                <p className="text-2xl font-bold">{c.value}</p>
                <p className="text-xs text-muted mt-1">{c.label}</p>
              </div>
            ))}
          </div>
        )}

        <div className="mt-10 glass rounded-2xl p-6">
          <h2 className="font-semibold mb-3">Quick Links</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            {["Live Sessions", "Reports", "Warnings", "Suspensions", "Bans", "Users/Sessions", "Analytics", "Audit Logs"].map((l) => (
              <button key={l} className="px-4 py-3 rounded-xl border border-border hover:bg-white/5 text-left transition-colors">
                {l}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted mt-4">
            Full moderation tools, live session view, and audit logs will be available once the backend services are configured.
          </p>
        </div>
      </div>
    </div>
  );
}
