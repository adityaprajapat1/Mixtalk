import { redirect } from "next/navigation";

export default function AdminRoot() {
  // Unauthenticated users are redirected to login
  redirect("/admin/login");
}
