import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Mail } from "@/components/Icons";

export const metadata = { title: "Contact Us" };

const categories = [
  { title: "General Support", email: "[SUPPORT_EMAIL]", desc: "Questions about using MixTalk" },
  { title: "Safety / Moderation", email: "[SAFETY_EMAIL]", desc: "Report issues or appeal decisions" },
  { title: "Privacy", email: "[PRIVACY_EMAIL]", desc: "Data protection and privacy inquiries" },
  { title: "Business", email: "[BUSINESS_EMAIL]", desc: "Partnerships and business inquiries" },
];

export default function ContactPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-3xl sm:text-4xl font-bold mb-6">Contact Us</h1>
          <p className="text-muted mb-10">
            Choose the category that best matches your inquiry. Addresses are
            configurable and will be set before launch.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            {categories.map((c) => (
              <div key={c.title} className="glass rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <Mail className="w-5 h-5 text-neon-blue" />
                  <h2 className="font-semibold">{c.title}</h2>
                </div>
                <p className="text-sm text-muted mb-3">{c.desc}</p>
                <p className="text-sm text-neon-blue font-mono">{c.email}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
