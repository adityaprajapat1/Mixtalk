"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/Header";
import { AgeGate } from "@/components/chat/AgeGate";
import { IdentitySelect } from "@/components/chat/IdentitySelect";
import { ModeSelect } from "@/components/chat/ModeSelect";
import { Searching } from "@/components/chat/Searching";
import { ChatRoom } from "@/components/chat/ChatRoom";
import { NoUsers } from "@/components/chat/NoUsers";
import { ConnectionLost } from "@/components/chat/ConnectionLost";
import { Under18 } from "@/components/chat/Under18";

export type ChatStep =
  | "age"
  | "under18"
  | "identity"
  | "mode"
  | "searching"
  | "matched"
  | "no-users"
  | "connection-lost";

export type Gender = "boy" | "girl" | null;
export type CommMode = "text" | "voice" | "video";

export interface SessionState {
  sessionId: string;
  nickname: string;
  gender: Gender;
  mode: CommMode | null;
  partnerNickname: string | null;
  matchId: string | null;
}

// Nickname pools (clean, non-offensive)
const BOY_NICKS = [
  "Nova", "Atlas", "Orion", "Kai", "Zen", "Axel", "Leo", "River", "Ash", "Finn",
  "Jett", "Cruz", "Blake", "Cole", "Drew", "Evan", "Gray", "Hayes", "Ian", "Jude",
];
const GIRL_NICKS = [
  "Luna", "Aria", "Nova", "Iris", "Sage", "Willow", "Eden", "Skye", "Quinn", "Remy",
  "Blair", "Casey", "Drew", "Ellis", "Finley", "Harper", "Indie", "Jules", "Kennedy", "Lane",
];

function pickNickname(gender: Gender): string {
  const pool = gender === "girl" ? GIRL_NICKS : BOY_NICKS;
  const base = pool[Math.floor(Math.random() * pool.length)];
  const num = Math.floor(Math.random() * 900) + 100;
  return `${base}${num}`;
}

function generateSessionId(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return "s_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

export default function ChatPage() {
  const [step, setStep] = useState<ChatStep>("age");
  const [session, setSession] = useState<SessionState | null>(null);

  // Restore or create session from sessionStorage (session-scoped)
  useEffect(() => {
    const existing = sessionStorage.getItem("mixtalk_session");
    if (existing) {
      try {
        const parsed = JSON.parse(existing) as SessionState;
        if (parsed.sessionId && parsed.nickname) {
          setSession(parsed);
          // If already past age + identity, go to mode
          if (parsed.gender) {
            setStep("mode");
          } else {
            setStep("identity");
          }
        }
      } catch {
        // ignore
      }
    }
  }, []);

  const persist = useCallback((s: SessionState) => {
    setSession(s);
    sessionStorage.setItem("mixtalk_session", JSON.stringify(s));
  }, []);

  const handleAgeYes = () => {
    const sid = generateSessionId();
    const newSession: SessionState = {
      sessionId: sid,
      nickname: "", // will be set after identity
      gender: null,
      mode: null,
      partnerNickname: null,
      matchId: null,
    };
    persist(newSession);
    setStep("identity");
  };

  const handleAgeNo = () => {
    setStep("under18");
  };

  const handleIdentity = (gender: Gender) => {
    if (!session) return;
    const nick = pickNickname(gender);
    const updated = { ...session, gender, nickname: nick };
    persist(updated);
    setStep("mode");
  };

  const handleMode = (mode: CommMode) => {
    if (!session) return;
    const updated = { ...session, mode };
    persist(updated);
    setStep("searching");
  };

  const handleMatched = (partnerNick: string, matchId: string, newSessionId?: string) => {
    if (!session) return;
    const updated = {
      ...session,
      sessionId: newSessionId || session.sessionId,
      partnerNickname: partnerNick,
      matchId,
    };
    persist(updated);
    setStep("matched");
  };

  const handleNoUsers = () => setStep("no-users");
  const handleConnectionLost = () => setStep("connection-lost");

  const handleSkip = () => {
    if (!session) return;
    // Clear partner, keep same nickname + session
    const updated = {
      ...session,
      partnerNickname: null,
      matchId: null,
    };
    persist(updated);
    setStep("searching");
  };

  const handleEnd = () => {
    setStep("mode");
    if (session) {
      persist({
        ...session,
        partnerNickname: null,
        matchId: null,
        mode: null,
      });
    }
  };

  const handleReturnHome = () => {
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {step !== "matched" && <Header />}
      <main className="flex-1 flex flex-col">
        {step === "age" && (
          <AgeGate onYes={handleAgeYes} onNo={handleAgeNo} />
        )}
        {step === "under18" && <Under18 />}
        {step === "identity" && session && (
          <IdentitySelect onSelect={handleIdentity} />
        )}
        {step === "mode" && session && (
          <ModeSelect
            nickname={session.nickname}
            onSelect={handleMode}
          />
        )}
        {step === "searching" && session && session.mode && (
          <Searching
            session={session}
            onMatched={handleMatched}
            onNoUsers={handleNoUsers}
            onConnectionLost={handleConnectionLost}
          />
        )}
        {step === "matched" && session && (
          <ChatRoom
            session={session}
            onSkip={handleSkip}
            onEnd={handleEnd}
            onConnectionLost={handleConnectionLost}
          />
        )}
        {step === "no-users" && (
          <NoUsers
            onTryAgain={() => setStep("searching")}
            onHome={handleReturnHome}
          />
        )}
        {step === "connection-lost" && (
          <ConnectionLost
            onReconnect={() => setStep("searching")}
            onFindOther={() => setStep("searching")}
            onEnd={handleEnd}
          />
        )}
      </main>
    </div>
  );
}
