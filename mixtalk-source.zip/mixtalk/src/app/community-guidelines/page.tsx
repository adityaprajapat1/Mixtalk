import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Community Guidelines" };

const rules = [
  "Be respectful.",
  "No harassment.",
  "No threats.",
  "No spam.",
  "No scams.",
  "No impersonation.",
  "No illegal activity.",
  "Do not expose another person's private information.",
  "Do not attempt to bypass bans.",
  "Follow applicable laws.",
  "Do not misuse MixTalk.",
  "Respect Report and Block systems.",
  "MixTalk is strictly 18+.",
];

export default function GuidelinesPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-3xl sm:text-4xl font-bold mb-6">
            Community Guidelines
          </h1>
          <p className="text-muted mb-8 leading-relaxed">
            These rules help keep MixTalk a place for respectful adult
            conversations. Violations may result in warnings, temporary
            suspension, or permanent removal.
          </p>
          <ol className="space-y-3">
            {rules.map((rule, i) => (
              <li
                key={i}
                className="glass rounded-xl px-5 py-4 flex items-start gap-4"
              >
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-neon-blue to-neon-purple flex items-center justify-center text-sm font-bold text-white">
                  {i + 1}
                </span>
                <span className="pt-1">{rule}</span>
              </li>
            ))}
          </ol>
        </div>
      </main>
      <Footer />
    </>
  );
}
