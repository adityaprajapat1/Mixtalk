import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { OnlineCounter } from "@/components/OnlineCounter";
import { MessageSquare, Mic, Video, SkipForward, Flag, Ban, Globe2, Shield } from "@/components/Icons";

export default function HomePage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          {/* Background glow */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-neon-purple/20 rounded-full blur-[120px]" />
            <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-neon-blue/15 rounded-full blur-[100px]" />
          </div>

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 pb-24 sm:pt-24 sm:pb-32">
            <div className="text-center">
              {/* Logo */}
              <div className="flex justify-center mb-8">
                <Image
                  src="/logo.png"
                  alt="MixTalk"
                  width={120}
                  height={120}
                  className="rounded-2xl neon-glow"
                  priority
                />
              </div>

              {/* Communication icons */}
              <div className="flex justify-center gap-6 sm:gap-10 mb-8">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-card border border-border flex items-center justify-center">
                    <MessageSquare className="w-7 h-7 text-neon-blue" />
                  </div>
                  <span className="text-xs text-muted">Text Chat</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-card border border-border flex items-center justify-center">
                    <Mic className="w-7 h-7 text-neon-purple" />
                  </div>
                  <span className="text-xs text-muted">Voice</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-card border border-border flex items-center justify-center">
                    <Video className="w-7 h-7 text-neon-pink" />
                  </div>
                  <span className="text-xs text-muted">Video</span>
                </div>
              </div>

              {/* Headline */}
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mb-4">
                <span className="gradient-text">Meet. Talk. Connect.</span>
              </h1>

              <p className="mx-auto max-w-2xl text-lg sm:text-xl text-muted mb-6 leading-relaxed">
                Meet new people from around the world through random text, voice
                and video conversations.
              </p>

              {/* 18+ badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-sm font-semibold mb-8">
                <Shield className="w-4 h-4" />
                18+ Adults Only
              </div>

              {/* Online counter */}
              <div className="mb-10">
                <OnlineCounter />
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/chat" className="btn-primary text-base sm:text-lg px-8 py-3.5 w-full sm:w-auto">
                  Start Chatting
                </Link>
                <Link href="/safety" className="btn-secondary text-base sm:text-lg px-8 py-3.5 w-full sm:w-auto">
                  Learn About Safety
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="py-20 border-t border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-14">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Talk to New People Around the World
              </h2>
              <p className="mx-auto max-w-2xl text-muted text-lg leading-relaxed">
                MixTalk lets eligible adults meet new people globally through
                random text, voice and video conversations. If you don&apos;t want
                to continue a conversation, simply use Skip and meet someone new.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: Globe2,
                  title: "Random Matching",
                  desc: "Get connected with eligible adults from different countries and cultures.",
                  color: "text-neon-blue",
                },
                {
                  icon: MessageSquare,
                  title: "Text Chat",
                  desc: "Real-time messaging with typing indicators and smooth conversation flow.",
                  color: "text-neon-blue",
                },
                {
                  icon: Mic,
                  title: "Voice Calls",
                  desc: "Talk face-to-face with crystal-clear voice using secure WebRTC.",
                  color: "text-neon-purple",
                },
                {
                  icon: Video,
                  title: "Video Calls",
                  desc: "See and talk with your match through high-quality video conversations.",
                  color: "text-neon-pink",
                },
                {
                  icon: SkipForward,
                  title: "Skip / Next",
                  desc: "Not feeling the conversation? Instantly move on to a new eligible person.",
                  color: "text-neon-purple",
                },
                {
                  icon: Flag,
                  title: "Report & Block",
                  desc: "Safety tools are always available. Report violations or block users easily.",
                  color: "text-neon-pink",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="glass rounded-2xl p-6 hover:bg-card-hover transition-colors"
                >
                  <div className={`w-12 h-12 rounded-xl bg-card border border-border flex items-center justify-center mb-4 ${item.color}`}>
                    <item.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Safety note */}
        <section className="py-16 border-t border-border">
          <div className="mx-auto max-w-3xl px-4 text-center">
            <div className="glass rounded-2xl p-8">
              <Shield className="w-10 h-10 text-neon-blue mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Safety First</h3>
              <p className="text-muted leading-relaxed mb-6">
                MixTalk is built for respectful adult conversations. Harassment,
                threats, spam and scams are not allowed. Use Report and Block
                whenever needed. MixTalk cannot guarantee that every interaction
                is safe — always use your judgment and keep personal information
                private.
              </p>
              <Link href="/safety" className="text-neon-blue hover:underline text-sm font-medium">
                Read our Safety guidelines →
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
