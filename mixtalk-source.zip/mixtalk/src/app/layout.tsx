import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "MixTalk — Meet. Talk. Connect.",
    template: "%s | MixTalk",
  },
  description:
    "MixTalk is an adults-only platform where eligible adults meet new people from around the world through random text, voice and video conversations.",
  keywords: [
    "random chat",
    "stranger chat",
    "video chat",
    "voice chat",
    "adults only",
    "18+",
    "MixTalk",
  ],
  authors: [{ name: "MixTalk" }],
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    title: "MixTalk — Meet. Talk. Connect.",
    description:
      "Meet new people from around the world through random text, voice and video conversations. 18+ Adults Only.",
    type: "website",
    siteName: "MixTalk",
  },
  twitter: {
    card: "summary_large_image",
    title: "MixTalk — Meet. Talk. Connect.",
    description:
      "Meet new people from around the world through random text, voice and video conversations. 18+ Adults Only.",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0b",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <body className="min-h-full flex flex-col bg-background text-foreground">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
