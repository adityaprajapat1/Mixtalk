import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Terms of Service</h1>
          <p className="text-muted text-sm mb-8">
            Last updated: [DATE] — Template only. Final Terms require legal review.
          </p>

          <div className="space-y-8 text-sm text-muted leading-relaxed">
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">1. Eligibility</h2>
              <p>You must be 18 years of age or older to use MixTalk. By using the platform you represent that you meet this requirement.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">2. Acceptable Use</h2>
              <p>You agree to use MixTalk only for lawful, respectful communication. Prohibited conduct includes harassment, threats, spam, scams, impersonation, illegal activity, and any attempt to bypass bans or security measures.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">3. User Responsibilities</h2>
              <p>You are responsible for your conduct and any content you transmit. Do not share sensitive personal information. Use Report and Block tools when appropriate.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">4. Moderation</h2>
              <p>MixTalk may issue warnings, temporary suspensions, or permanent bans for violations of these Terms or Community Guidelines. Moderation decisions are based on defined rules and available evidence.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">5. Privacy</h2>
              <p>Your use of MixTalk is also governed by our Privacy Policy.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">6. Intellectual Property</h2>
              <p>MixTalk branding, design, and software are protected. You may not copy, reverse-engineer, or misuse the platform.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">7. Service Changes & Availability</h2>
              <p>We may modify, suspend, or discontinue features at any time. We do not guarantee uninterrupted availability.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">8. Liability</h2>
              <p>MixTalk is provided &quot;as is&quot;. To the fullest extent permitted by law, we disclaim liability for user conduct, content, or any damages arising from use of the service.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">9. Governing Law</h2>
              <p>[GOVERNING LAW / JURISDICTION PLACEHOLDER]</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-foreground mb-2">10. Contact</h2>
              <p>[LEGAL COMPANY NAME]<br />[CONTACT EMAIL]<br />[BUSINESS ADDRESS]</p>
            </section>
          </div>

          <p className="text-xs text-muted mt-12 border-t border-border pt-6">
            This is a development template. Obtain appropriate legal review before launching.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}
