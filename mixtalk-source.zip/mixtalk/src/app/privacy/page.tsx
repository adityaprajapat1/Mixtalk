import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-16 prose prose-invert prose-sm max-w-none">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Privacy Policy</h1>
          <p className="text-muted text-sm mb-8">
            Last updated: [DATE] — This is a template. Final policy must receive
            appropriate legal review before launch.
          </p>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">1. Information We Collect</h2>
            <p className="text-muted text-sm leading-relaxed">
              MixTalk is designed with data minimization. We collect only what is
              needed for platform operation, security, and moderation:
            </p>
            <ul className="list-disc list-inside text-muted text-sm mt-2 space-y-1">
              <li>Temporary session IDs (generated server-side)</li>
              <li>Approximate country/region (privacy-preserving, not exact GPS)</li>
              <li>Communication type preference (text / voice / video)</li>
              <li>Reports and moderation-related data</li>
              <li>Technical data necessary for security and abuse prevention</li>
              <li>Optional feedback or contact form submissions</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">2. What We Do Not Collect</h2>
            <p className="text-muted text-sm leading-relaxed">
              We do not require traditional account registration for basic use.
              We do not publicly reveal real names, phone numbers, email addresses,
              IP addresses, exact GPS location, or internal session IDs to other users.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">3. Cookies & Local Storage</h2>
            <p className="text-muted text-sm leading-relaxed">
              We may use cookies and local/session storage for session management,
              language preference, and theme. You can control cookies through your
              browser settings.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">4. Data Retention & Deletion</h2>
            <p className="text-muted text-sm leading-relaxed">
              Temporary session data is retained only as long as necessary for
              operation, security, and moderation. Expired data is automatically
              removed according to our retention policy.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">5. Third-Party Services</h2>
            <p className="text-muted text-sm leading-relaxed">
              We may use third-party infrastructure (hosting, STUN/TURN, analytics)
              under appropriate data processing terms. Details will be listed here
              once providers are finalized.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">6. Contact</h2>
            <p className="text-muted text-sm leading-relaxed">
              For privacy-related inquiries:<br />
              [PRIVACY CONTACT]<br />
              [LEGAL COMPANY NAME]<br />
              [BUSINESS ADDRESS]<br />
              [CONTACT EMAIL]
            </p>
          </section>

          <p className="text-xs text-muted mt-12 border-t border-border pt-6">
            This template is provided for development purposes. The operator must
            obtain appropriate legal review for the final Privacy Policy before
            launch in any jurisdiction.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}
