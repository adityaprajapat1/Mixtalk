"use client";

import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const TYPES = ["Bug", "Feature request", "Safety", "General feedback", "Other"];

export default function FeedbackPage() {
  const [type, setType] = useState("");
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!type || !message.trim()) return;
    setLoading(true);
    try {
      await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, message: message.trim(), email: email.trim() || undefined }),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-lg px-4 py-16">
          <h1 className="text-3xl font-bold mb-2">Feedback</h1>
          <p className="text-muted text-sm mb-8">
            Help us improve MixTalk. We read every submission.
          </p>

          {submitted ? (
            <div className="glass rounded-2xl p-8 text-center">
              <div className="text-4xl mb-4">✓</div>
              <h2 className="text-xl font-semibold mb-2">Thank you!</h2>
              <p className="text-muted text-sm">Your feedback has been received.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium mb-2">Feedback type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  required
                  className="w-full bg-card border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-purple"
                >
                  <option value="">Select type...</option>
                  {TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Message</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  rows={5}
                  maxLength={2000}
                  className="w-full bg-card border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-purple resize-none"
                  placeholder="Tell us what's on your mind..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Email <span className="text-muted">(optional)</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-card border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-neon-purple"
                  placeholder="you@example.com"
                />
              </div>
              <button
                type="submit"
                disabled={loading || !type || !message.trim()}
                className="btn-primary w-full disabled:opacity-40"
              >
                {loading ? "Sending..." : "Send Feedback"}
              </button>
            </form>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
