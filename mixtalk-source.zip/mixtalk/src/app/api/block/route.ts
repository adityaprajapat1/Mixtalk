import { NextRequest, NextResponse } from "next/server";
import { getSession, addBlock } from "@/lib/session";
import { endMatch } from "@/lib/matching";
import { getPrisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { sessionId, matchId } = body;
    if (!sessionId) {
      return NextResponse.json({ error: "Missing sessionId" }, { status: 400 });
    }

    const me = await getSession(sessionId);
    if (!me) {
      return NextResponse.json({ error: "Invalid session" }, { status: 400 });
    }

    if (me.partnerId) {
      await addBlock(sessionId, me.partnerId);
      const prisma = getPrisma();
      if (prisma) {
        try {
          await prisma.block.create({
            data: { blockerId: sessionId, blockedId: me.partnerId },
          });
        } catch {
          // may already exist
        }
      }
    }

    await endMatch(sessionId, { skip: true, reason: "block" });
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[block]", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
