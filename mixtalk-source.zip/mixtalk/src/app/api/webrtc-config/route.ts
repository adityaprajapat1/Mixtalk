import { NextResponse } from "next/server";

/**
 * Returns ICE server config. TURN credentials stay on the server;
 * only the necessary connection info is sent to the client for the current session.
 */
export async function GET() {
  const iceServers: RTCIceServer[] = [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
  ];

  const turnServer = process.env.TURN_SERVER;
  const turnUser = process.env.TURN_USERNAME;
  const turnPass = process.env.TURN_PASSWORD;
  let turnConfigured = false;

  if (turnServer && turnUser && turnPass) {
    iceServers.push({
      urls: turnServer,
      username: turnUser,
      credential: turnPass,
    });
    turnConfigured = true;
  }

  return NextResponse.json(
    { iceServers, turnConfigured },
    { headers: { "Cache-Control": "no-store" } }
  );
}

// Type for the response shape
interface RTCIceServer {
  urls: string | string[];
  username?: string;
  credential?: string;
}
