import { randomUUID } from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { getPrisma } from "@/lib/db";
import { getRedis, Keys } from "@/lib/redis";

const ALLOWED = new Set([
  "Harassment", "Abusive behavior", "Threatening behavior", "Spam",
  "Scam/fraud", "Inappropriate behavior", "Impersonation", "Other",
]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { sessionId, matchId, reason, description } = body;
    if (!sessionId || !reason || !ALLOWED.has(reason)) {
      return NextResponse.json({ error: "Invalid report" }, { status: 400 });
    }

    const reporter = await getSession(sessionId);
    if (!reporter) {
      return NextResponse.json({ error: "Invalid session" }, { status: 400 });
    }

    const reportedId = reporter.partnerId;
    const reportId = randomUUID();
    const payload = {
      id: reportId,
      reporterId: sessionId,
      reportedId: reportedId || "unknown",
      matchId: matchId || null,
      reason,
      description: typeof description === "string" ? description.slice(0, 500) : null,
      status: "PENDING",
      createdAt: new Date().toISOString(),
    };

    // Always store in Redis for immediate admin visibility
    const redis = getRedis();
    await redis.set(`mt:report:${reportId}`, JSON.stringify(payload), "EX", 60 * 60 * 24 * 30);
    await redis.sadd("mt:reports:pending", reportId);

    // Persist to DB when available
    const prisma = getPrisma();
    if (prisma && reportedId) {
      try {
        await prisma.report.create({
          data: {
            id: reportId,
            reporterId: sessionId,
            reportedId,
            matchId: matchId || undefined,
            reason: reason.toUpperCase().replace(/[^A-Z]/g, "_").replace(/_+/g, "_") as any,
            description: payload.description || undefined,
            status: "PENDING",
          },
        });
      } catch (e) {
        console.warn("[report] DB write skipped:", e);
      }
    }

    return NextResponse.json({ success: true, reportId });
  } catch (err) {
    console.error("[report]", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
