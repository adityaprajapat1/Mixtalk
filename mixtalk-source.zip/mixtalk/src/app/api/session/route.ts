import { NextRequest, NextResponse } from "next/server";
import { createSession, getSession, updateSession } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const gender = body.gender === "boy" || body.gender === "girl" ? body.gender : null;
    // Approximate region from headers if available (privacy-preserving)
    const cf = req.headers.get("cf-ipcountry") || req.headers.get("x-vercel-ip-country");
    const approxRegion = cf && cf !== "XX" ? cf : null;

    const session = await createSession({ gender, approxRegion });
    return NextResponse.json({
      sessionId: session.id,
      nickname: session.nickname,
      gender: session.gender,
    });
  } catch (err) {
    console.error("[session]", err);
    return NextResponse.json({ error: "Failed to create session" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  const session = await getSession(id);
  if (!session) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    sessionId: session.id,
    nickname: session.nickname,
    gender: session.gender,
    mode: session.mode,
    matchId: session.matchId,
  });
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { sessionId, gender, mode } = body;
    if (!sessionId) return NextResponse.json({ error: "Missing sessionId" }, { status: 400 });
    const patch: Record<string, unknown> = {};
    if (gender === "boy" || gender === "girl") patch.gender = gender;
    if (mode === "text" || mode === "voice" || mode === "video") patch.mode = mode;
    const updated = await updateSession(sessionId, patch as any);
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({
      sessionId: updated.id,
      nickname: updated.nickname,
      gender: updated.gender,
      mode: updated.mode,
    });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
