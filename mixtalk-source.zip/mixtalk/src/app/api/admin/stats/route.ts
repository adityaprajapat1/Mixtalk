import { NextRequest, NextResponse } from "next/server";
import { verifyAdminToken, COOKIE_NAME, hasRole } from "@/lib/admin-auth";
import { getActiveCount } from "@/lib/session";
import { getQueueSize } from "@/lib/matching";
import { getRedis } from "@/lib/redis";
import { getPrisma } from "@/lib/db";

async function requireAdmin(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyAdminToken(token);
}

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasRole(admin.role, "MODERATOR")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const redis = getRedis();
    const [activeUsers, textQ, voiceQ, videoQ, pendingReports] = await Promise.all([
      getActiveCount(),
      getQueueSize("text"),
      getQueueSize("voice"),
      getQueueSize("video"),
      redis.scard("mt:reports:pending"),
    ]);

    let warnings = 0;
    let suspensions = 0;
    let bans = 0;
    let textChats = 0;
    let voiceCalls = 0;
    let videoCalls = 0;

    const prisma = getPrisma();
    if (prisma) {
      try {
        const [w, s, b] = await Promise.all([
          prisma.warning.count(),
          prisma.session.count({ where: { isSuspended: true } }),
          prisma.session.count({ where: { isBanned: true } }),
        ]);
        warnings = w;
        suspensions = s;
        bans = b;
      } catch {
        // schema may not be migrated yet
      }
    }

    return NextResponse.json({
      activeUsers,
      textChats: textChats + textQ,
      voiceCalls: voiceCalls + voiceQ,
      videoCalls: videoCalls + videoQ,
      pendingReports,
      warnings,
      suspensions,
      bans,
      queues: { text: textQ, voice: voiceQ, video: videoQ },
    });
  } catch (err) {
    console.error("[admin/stats]", err);
    return NextResponse.json({ error: "Failed to load stats" }, { status: 500 });
  }
}
