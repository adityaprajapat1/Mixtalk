import { NextRequest, NextResponse } from "next/server";
import { findMatch, endMatch } from "@/lib/matching";
import { getSession, updateSession, createSession, type CommMode } from "@/lib/session";
import { getActiveCount } from "@/lib/session";

/**
 * POST /api/match
 * Real matching against Redis/memory queue. Returns 204 when no eligible users.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    let { sessionId, nickname, gender, mode } = body as {
      sessionId?: string;
      nickname?: string;
      gender?: "boy" | "girl" | null;
      mode?: CommMode;
    };

    if (!mode || !["text", "voice", "video"].includes(mode)) {
      return NextResponse.json({ error: "Invalid mode" }, { status: 400 });
    }

    // Create or resume session
    let session = sessionId ? await getSession(sessionId) : null;
    if (!session) {
      session = await createSession({ gender: gender ?? null });
      sessionId = session.id;
    } else {
      // Keep existing nickname for the session
      if (gender && !session.gender) {
        session = (await updateSession(session.id, { gender })) || session;
      }
      sessionId = session.id;
    }

    const result = await findMatch(sessionId, mode);

    if (!result) {
      // Still searching — return session id so client can poll / connect WS
      return NextResponse.json(
        { status: "searching", sessionId, nickname: session.nickname },
        { status: 202 }
      );
    }

    return NextResponse.json({
      status: "matched",
      sessionId,
      nickname: session.nickname,
      matchId: result.matchId,
      partnerNickname: result.partnerNickname,
      partnerGender: result.partnerGender,
    });
  } catch (err) {
    console.error("[match]", err);
    return NextResponse.json({ error: "Matching failed" }, { status: 500 });
  }
}

/**
 * DELETE /api/match — leave queue or end match (skip/end)
 */
export async function DELETE(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { sessionId, skip } = body as { sessionId?: string; skip?: boolean };
    if (!sessionId) {
      return NextResponse.json({ error: "Missing sessionId" }, { status: 400 });
    }
    await endMatch(sessionId, { skip: Boolean(skip) });
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[match/end]", err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
