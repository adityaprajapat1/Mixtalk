import { NextResponse } from "next/server";
import { getActiveCount } from "@/lib/session";
import { isUsingMemoryStore, isRedisConfigured } from "@/lib/redis";

export async function GET() {
  try {
    const count = await getActiveCount();
    return NextResponse.json(
      {
        count,
        store: isRedisConfigured() && !isUsingMemoryStore() ? "redis" : "memory",
      },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch {
    return NextResponse.json({ count: 0, store: "error" }, { status: 200 });
  }
}
