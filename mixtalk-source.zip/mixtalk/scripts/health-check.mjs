#!/usr/bin/env node
/**
 * MixTalk health check
 * Status values: READY | NOT CONFIGURED | CONNECTION FAILED | DEPENDENCY INSTALL FAILED
 */
import { readFileSync, existsSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";
import { createRequire } from "module";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, "..");
const require = createRequire(import.meta.url);

// Load .env.local manually (no dotenv dependency required)
function loadEnv() {
  const path = resolve(ROOT, ".env.local");
  if (!existsSync(path)) return {};
  const env = {};
  for (const line of readFileSync(path, "utf8").split("\n")) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const i = t.indexOf("=");
    if (i === -1) continue;
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'")))
      v = v.slice(1, -1);
    env[k] = v;
    if (!process.env[k]) process.env[k] = v;
  }
  return env;
}

const env = loadEnv();
const results = [];

function row(component, status, detail) {
  results.push({ component, status, detail });
}

function has(pkg) {
  try {
    require.resolve(pkg, { paths: [ROOT] });
    return true;
  } catch {
    return false;
  }
}

console.log("============================================");
console.log(" MixTalk Health Check");
console.log("============================================\n");

// --- npm dependencies ---
const required = [
  "next", "react", "react-dom",
  "ioredis", "bcryptjs", "jose", "socket.io", "socket.io-client",
  "@prisma/client", "zod",
];
const missing = required.filter((p) => !has(p));
if (missing.length === 0) {
  row("npm dependencies", "READY", "All required packages resolve");
} else {
  row(
    "npm dependencies",
    "DEPENDENCY INSTALL FAILED",
    `Missing: ${missing.join(", ")}. Run: npm install`
  );
}

// --- SESSION_SECRET ---
const secret = process.env.SESSION_SECRET || "";
if (secret.length >= 32) {
  row("SESSION_SECRET", "READY", `Set (${secret.length} chars)`);
} else if (secret) {
  row("SESSION_SECRET", "NOT CONFIGURED", "Too short (need >= 32 chars)");
} else {
  row("SESSION_SECRET", "NOT CONFIGURED", "Missing in .env.local");
}

// --- Admin auth ---
const adminEmail = process.env.ADMIN_EMAIL || "";
const adminHash = process.env.ADMIN_PASSWORD_HASH || "";
if (adminEmail && adminHash && adminHash.startsWith("$2") && secret.length >= 32) {
  row("Admin authentication", "READY", `Bootstrap email set: ${adminEmail}`);
} else if (!adminEmail && !adminHash) {
  row(
    "Admin authentication",
    "NOT CONFIGURED",
    "Set ADMIN_EMAIL and ADMIN_PASSWORD_HASH (npx tsx scripts/hash-password.ts)"
  );
} else {
  row(
    "Admin authentication",
    "NOT CONFIGURED",
    "Incomplete: need ADMIN_EMAIL + bcrypt ADMIN_PASSWORD_HASH + SESSION_SECRET"
  );
}

// --- 2FA ---
const totp = process.env.ADMIN_TOTP_SECRET || "";
if (totp) {
  row("2FA (TOTP)", "READY", "ADMIN_TOTP_SECRET is set");
} else {
  row(
    "2FA (TOTP)",
    "NOT CONFIGURED",
    "Optional in development; required for production (set ADMIN_TOTP_SECRET)"
  );
}

// --- PostgreSQL ---
const dbUrl = process.env.DATABASE_URL || "";
if (!dbUrl) {
  row("PostgreSQL", "NOT CONFIGURED", "DATABASE_URL empty — Prisma persistence disabled");
  row("Database migrations", "NOT CONFIGURED", "Requires DATABASE_URL");
} else {
  // Attempt connection only if prisma client available
  (async () => {
    // handled below in async section
  })();
}

// --- Redis ---
const redisUrl = process.env.REDIS_URL || "";
if (!redisUrl) {
  row(
    "Redis",
    "NOT CONFIGURED",
    "REDIS_URL empty — using in-memory store (single-process only)"
  );
}

// --- WebSocket ---
const wsPort = process.env.WS_PORT || "3001";
const wsUrl = process.env.NEXT_PUBLIC_WS_URL || "";
row(
  "WebSocket config",
  wsUrl ? "READY" : "NOT CONFIGURED",
  wsUrl
    ? `NEXT_PUBLIC_WS_URL=${wsUrl}, WS_PORT=${wsPort}`
    : "NEXT_PUBLIC_WS_URL not set (ChatRoom falls back to origin:3001)"
);

// --- WebRTC / TURN ---
const turnServer = process.env.TURN_SERVER || "";
const turnUser = process.env.TURN_USERNAME || "";
const turnPass = process.env.TURN_PASSWORD || "";
if (turnServer && turnUser && turnPass) {
  row("TURN", "READY", `TURN_SERVER=${turnServer}`);
} else if (turnServer || turnUser || turnPass) {
  row("TURN", "NOT CONFIGURED", "Partial TURN_* vars — need all three");
} else {
  row(
    "TURN",
    "NOT CONFIGURED",
    "No TURN credentials — STUN-only (may fail behind strict NAT)"
  );
}
row("WebRTC signaling", "READY", "Implemented in server/ws-server.ts + /api/webrtc-config");

// --- Production build (presence of next binary) ---
if (has("next")) {
  row("Production build tooling", "READY", "next package present (run: npm run build)");
} else {
  row("Production build tooling", "DEPENDENCY INSTALL FAILED", "next not installed");
}

// Async checks: Redis + Postgres
async function asyncChecks() {
  // Redis
  if (redisUrl) {
    if (!has("ioredis")) {
      row("Redis", "DEPENDENCY INSTALL FAILED", "ioredis not installed");
    } else {
      try {
        const Redis = require("ioredis");
        const r = new Redis(redisUrl, {
          maxRetriesPerRequest: 1,
          connectTimeout: 3000,
          lazyConnect: true,
        });
        await r.connect();
        await r.ping();
        await r.quit();
        row("Redis", "READY", `Connected to ${redisUrl.replace(/:[^:@]+@/, ":***@")}`);
      } catch (e) {
        row("Redis", "CONNECTION FAILED", String(e.message || e));
      }
    }
  }

  // Postgres
  if (dbUrl) {
    if (!has("@prisma/client")) {
      row("PostgreSQL", "DEPENDENCY INSTALL FAILED", "@prisma/client not installed");
      row("Database migrations", "DEPENDENCY INSTALL FAILED", "prisma client missing");
    } else {
      try {
        const { PrismaClient } = require("@prisma/client");
        const prisma = new PrismaClient({
          datasources: { db: { url: dbUrl } },
        });
        await prisma.$connect();
        await prisma.$queryRaw`SELECT 1`;
        await prisma.$disconnect();
        row("PostgreSQL", "READY", "Connection successful");
        row(
          "Database migrations",
          "READY",
          "DB reachable — run: npx prisma db push (or migrate)"
        );
      } catch (e) {
        row("PostgreSQL", "CONNECTION FAILED", String(e.message || e));
        row(
          "Database migrations",
          "CONNECTION FAILED",
          "Fix DATABASE_URL before running migrations"
        );
      }
    }
  }

  // Print table
  console.log("Component                      | Status                      | Detail");
  console.log("-".repeat(100));
  for (const r of results) {
    const c = r.component.padEnd(30);
    const s = r.status.padEnd(28);
    console.log(`${c}| ${s}| ${r.detail}`);
  }
  console.log("");

  const failed = results.filter((r) =>
    ["CONNECTION FAILED", "DEPENDENCY INSTALL FAILED"].includes(r.status)
  );
  const notConfig = results.filter((r) => r.status === "NOT CONFIGURED");
  const ready = results.filter((r) => r.status === "READY");

  console.log(`READY: ${ready.length}  |  NOT CONFIGURED: ${notConfig.length}  |  FAILED: ${failed.length}`);
  console.log("");

  if (failed.length > 0) {
    console.log("MixTalk is NOT production-ready — fix FAILED items above.");
    process.exitCode = 1;
  } else if (notConfig.some((r) =>
    ["Admin authentication", "SESSION_SECRET", "npm dependencies"].includes(r.component)
  )) {
    console.log("Core items still NOT CONFIGURED. App can run in limited mode but admin/auth need setup.");
    process.exitCode = 0;
  } else {
    console.log("Core checks passed. Optional services (Redis/Postgres/TURN/2FA) may still be NOT CONFIGURED.");
    process.exitCode = 0;
  }
}

asyncChecks().catch((e) => {
  console.error("Health check error:", e);
  process.exit(1);
});
